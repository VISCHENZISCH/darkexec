#!/usr/bin/env python3
# coding: utf-8

import socket
import sys

HOST = ""
PORT = 50000


def recv_exact(sock, n):
   
    buf = b""
    while len(buf) < n:
        chunk = sock.recv(n - len(buf))
        if not chunk:
            return None
        buf += chunk
    return buf


def main():
    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    srv.bind((HOST, PORT))
    srv.listen(5)

    print("")
    print("*" * 40)
    print(f"[+] Listening on {HOST or '*'} :{PORT}")
    print("*" * 40)

    while True:
        try:
            conn, addr = srv.accept()
        except KeyboardInterrupt:
            break

        print(f"[+] Connection from {addr}")

        with conn:
            while True:
                try:
                    cmd = input("%> ").strip()
                except (EOFError, KeyboardInterrupt):
                    print("\n[-] Closing")
                    srv.close()
                    return

                if not cmd:
                    continue

                try:

                    conn.sendall(cmd.encode("cp850", errors="replace") + b"\n")


                    hdr = recv_exact(conn, 4)
                    if hdr is None:
                        print("[-] Client disconnected")
                        break
                    size = int.from_bytes(hdr, "big")

                    data = recv_exact(conn, size) if size else b""
                    if data is None:
                        print("[-] Client disconnected")
                        break


                    sys.stdout.write(data.decode("cp850", errors="replace"))
                    sys.stdout.write("\n")
                    sys.stdout.flush()

                except (ConnectionResetError, BrokenPipeError, OSError) as e:
                    print(f"[-] Network error: {e}")
                    break

    srv.close()


if __name__ == "__main__":
    main()
